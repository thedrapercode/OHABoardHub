=== OHA Board Hub – Suite ===
Contributors: OHA
Tags: stripe, membership, simple membership, board hub, vendor
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.2.3
License: GPLv2 or later

Combines OHA Board Hub (frontend), OHA Stripe (Minimal), OHA Board Hub – Stripe Admin, and Vendor Convention 2026 into one tabbed admin UI.

== Highlights ==
- Unified settings for Stripe keys/webhook and membership checkout.
- Admin tabs: Membership, Board Hub Settings, Stripe Settings, Convention 2026, Webhooks, Tools, Debug.
- Frontend Board Hub (shortcode [oha_board_hub]) shows Stripe Admin console on Members tab.
- Frontend Convention 2026 tab renders the Vendor Applications dashboard directly (no placeholder).
- Auto-downgrade to Free (configurable) when Stripe subscription is canceled at period end.

== Installation ==
1) Deactivate standalone OHA plugins included above, then upload and activate this Suite.
2) Configure settings under Admin → OHA Board Hub.

== Webhook ==
Defaults to /wp-json/oha/v1/stripe-webhook (configurable).


== 1.3.15 ==
* Added Featured Sync module: keeps GeoDirectory `featured` flag, Featured category, and default_category aligned.
* New admin page: Board Hub → Featured Sync. Supports action-driven or meta-watcher modes.

== 1.3.16 ==
* Frontend discount toggle now fires `oha_discount_activated` / `oha_discount_deactivated` hooks so Featured Sync runs from the frontend.

== 1.3.18 ==
* Fix: ensures a top-level 'Board Hub' menu exists so the Featured Sync submenu never 404s.

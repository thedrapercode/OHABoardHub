<?php
/**
 * Plugin Name: OHA Board Hub – Suite
 * Description: Unified plugin combining OHA Board Hub (frontend), OHA Stripe (Minimal), Board Hub – Stripe Admin, and Vendor Convention 2026 into one admin with tabs and a single settings store.
 * Version: 1.4.3
 * Author: OHA
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) exit;

define('OHA_BHS_OPT', 'oha_bh_suite_settings');
define('OHA_BHS_MENU', 'oha-board-hub');

// Load embedded libs (menus/routes are stripped)
require_once __DIR__ . '/includes/oha-stripe-minimal.lib.php';
require_once __DIR__ . '/includes/oha-featured-sync.lib.php';
require_once __DIR__ . '/includes/oha-boardhub-stripe-admin.lib.php';
require_once __DIR__ . '/includes/oha-vendor-2026.lib.php';
require_once __DIR__ . '/includes/oha-board-hub.lib.php';
require_once __DIR__ . '/includes/oha-haunt-discounts.lib.php';

/** ================== 
 * Settings Sync (single source of truth)
 * - We keep one option array (OHA_BHS_OPT) and mirror to the legacy options.
 */
function oha_bhs_defaults(){
    return array(
        'stripe' => array(
            'secret_key' => '',
            'webhook_secret' => '',
            'endpoint_path' => 'oha/v1/stripe-webhook',
            'timestamp_tolerance' => 300,
            'portal_return_url' => home_url('/'),
            'invoice_limit' => 12,
            'price_filter' => '',
            'price_signup_20' => '',
            'price_yearly_10' => '',
            'membership_level_id' => 0,
            'trial_end_iso' => '',
            'log' => 1,
        ),
        'vendor' => array(
            'front_cap' => 'edit_posts',
            'convention_2026_page_id' => 0,
        ),
        'swpm' => array(
            'free_level_id' => 2,
            'paid_level_id' => 10,
        ),
    );
}
function oha_bhs_get(){
    $opt = get_option(OHA_BHS_OPT, array());
    $def = oha_bhs_defaults();
    foreach($def as $k=>$v){
        if(!isset($opt[$k]) || !is_array($opt[$k])) $opt[$k] = $v;
        else $opt[$k] = array_merge($v, $opt[$k]);
    }
    return $opt;
}
function oha_bhs_update($new){
    $opt = oha_bhs_get();
    $opt = array_replace_recursive($opt, $new);
    update_option(OHA_BHS_OPT, $opt);
    return $opt;
}

// Legacy read map
add_filter('pre_option_oha_sm_settings', function($pre){ $o=oha_bhs_get(); return $o['stripe']; });
add_filter('pre_option_oha_sa_settings', function($pre){ $o=oha_bhs_get(); return $o['stripe']; });
add_filter('pre_option_oha_vbh_front_cap', function($pre){ $o=oha_bhs_get(); return $o['vendor']['front_cap']; });
add_filter('pre_option_oha_vbh_convention_2026_page_id', function($pre){ $o=oha_bhs_get(); return $o['vendor']['convention_2026_page_id']; });

// Legacy write map
add_filter('pre_update_option_oha_sm_settings', function($value){ $opt=oha_bhs_update(array('stripe'=>(array)$value)); return $opt['stripe']; }, 10, 1);
add_filter('pre_update_option_oha_sa_settings', function($value){ $opt=oha_bhs_update(array('stripe'=>(array)$value)); return $opt['stripe']; }, 10, 1);
add_filter('pre_update_option_oha_vbh_front_cap', function($value){ oha_bhs_update(array('vendor'=>array('front_cap'=>$value))); return $value; }, 10, 1);
add_filter('pre_update_option_oha_vbh_convention_2026_page_id', function($value){ oha_bhs_update(array('vendor'=>array('convention_2026_page_id'=>intval($value)))); return intval($value); }, 10, 1);

/** ================== 
 * Admin UI
 */
add_action('admin_menu', function(){
    add_menu_page('OHA Board Hub', 'OHA Board Hub', 'manage_options', OHA_BHS_MENU, 'oha_bhs_admin_page', 'dashicons-admin-generic', 64);
});

function oha_bhs_admin_page(){
    if(!current_user_can('manage_options')) return;
    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'membership';
    $tabs = array(
        'membership' => 'Membership',
        'boardhub' => 'Board Hub Settings',
        'stripe' => 'Stripe Settings',
        'vendor' => 'Convention 2026',
        'webhooks' => 'Webhooks',
        'tools' => 'Tools',
        'debug' => 'Debug',
        'discounts' => 'Haunt Discounts',
    );
    echo '<div class="wrap"><h1>OHA Board Hub – Suite</h1><h2 class="nav-tab-wrapper">';
    foreach($tabs as $k=>$label){
        $cls = ($k===$tab)?' nav-tab-active':'';
        echo '<a class="nav-tab'.$cls.'" href="'.esc_url(add_query_arg('tab',$k,menu_page_url(OHA_BHS_MENU,false))).'">'.esc_html($label).'</a>';
    }
    echo '</h2>';
    echo '<div style="background:#fff;padding:16px;border:1px solid #ccd0d4;border-top:none; border-radius:0 0 6px 6px;">';
    switch($tab){
        case 'membership': oha_bhs_tab_membership(); break;
        case 'boardhub': oha_bhs_tab_boardhub(); break;
        case 'stripe': oha_bhs_tab_stripe(); break;
        case 'vendor': oha_bhs_tab_vendor(); break;
        case 'webhooks': oha_bhs_tab_webhooks(); break;
        case 'tools': oha_bhs_tab_tools(); break;
        case 'debug': oha_bhs_tab_debug(); break;
        case 'discounts': oha_bhs_tab_discounts(); break;
        default: oha_bhs_tab_membership();
    }
    echo '</div></div>';
}

function oha_bhs_tab_membership(){
    echo '<h2>Members</h2>';
    echo '<p>Stripe management (Cancel / Resume / Swap / Renew) below. SWPM current members listed for reference.</p>';
    echo do_shortcode('[oha_board_stripe_admin]');
    global $wpdb; $table=$wpdb->prefix.'swpm_members_tbl';
    $exists=$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
    if($exists){
        $q = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';
        $sql = "SELECT member_id, user_name, first_name, last_name, email, account_state, membership_level FROM {$table}";
        if($q){
            $like = '%'.$wpdb->esc_like($q).'%';
            $sql .= $wpdb->prepare(" WHERE user_name LIKE %s OR email LIKE %s OR first_name LIKE %s OR last_name LIKE %s", $like,$like,$like,$like);
        }
        $sql .= " ORDER BY member_id DESC LIMIT 100";
        $rows = $wpdb->get_results($sql, ARRAY_A);
        echo '<form method="get" style="margin:12px 0;">';
        foreach(['page','tab'] as $keep){ if(isset($_GET[$keep])) echo '<input type="hidden" name="'.esc_attr($keep).'" value="'.esc_attr($_GET[$keep]).'">'; }
        echo '<input type="search" name="q" value="'.esc_attr($q).'" placeholder="Search members (name/email/username)"> ';
        submit_button('Search', 'secondary', '', false);
        echo '</form>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Username</th><th>Name</th><th>Email</th><th>Level</th><th>Status</th></tr></thead><tbody>';
        foreach($rows as $r){
            $name = trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? ''));
            echo '<tr><td>'.intval($r['member_id']).'</td><td>'.esc_html($r['user_name']).'</td><td>'.esc_html($name).'</td><td>'.esc_html($r['email']).'</td><td>'.esc_html($r['membership_level']).'</td><td>'.esc_html($r['account_state']).'</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p><em>SWPM members table not found ('.$table.').</em></p>';
    }
}

function oha_bhs_tab_boardhub(){
    echo '<h2>Board Hub Settings</h2>';
    if(class_exists('OHA_Board_Hub')){
        $obj = new OHA_Board_Hub();
        if(method_exists($obj,'settings_page')){
            $obj->settings_page();
            return;
        }
    }
    echo '<p><em>Board Hub class not available.</em></p>';
}

function oha_bhs_tab_stripe(){
    echo '<h2>Stripe Settings</h2>';
    if(function_exists('oha_sm_settings_page')){
        oha_sm_settings_page();
    } else {
        echo '<p>Stripe Minimal not loaded.</p>';
    }
}

function oha_bhs_tab_vendor(){
    echo '<h2>Convention 2026</h2>';
    if (shortcode_exists('oha_vendor_board_hub')) {
        echo '<div class="card" style="padding:12px;margin-bottom:16px;">';
        echo do_shortcode('[oha_vendor_board_hub]');
        echo '</div>';
    } else {
        echo '<p><em>Vendor dashboard not available.</em></p>';
    }
    if(function_exists('oha_vbh_2026_settings')){
        echo '<hr style="margin:20px 0;">';
        oha_vbh_2026_settings();
    }
}

function oha_bhs_tab_webhooks(){
    $s=oha_bhs_get(); $path=trim($s['stripe']['endpoint_path'],'/');
    echo '<h2>Webhook Endpoint</h2>';
    echo '<p>Currently listening on: <code>'.esc_html(home_url('/'.$path)).'</code></p>';
    echo '<p>Events handled: checkout.session.completed, customer.created/updated, customer.subscription.created/updated/deleted, invoice.payment_succeeded</p>';
    echo '<p>When a member cancels at period end, we schedule automatic downgrade to Free (Level '.intval(oha_bhs_get()['swpm']['free_level_id']).').</p>';
}

function oha_bhs_tab_tools(){
    if(function_exists('oha_sm_tools_page')){
        oha_sm_tools_page();
    } else {
        echo '<p>No tools available.</p>';
    }
}
function oha_bhs_tab_debug(){
    if(function_exists('oha_sm_debug_page')){
        oha_sm_debug_page();
    } else {
        echo '<p>No debug available.</p>';
    }
}

/** ================
 * Webhook (unified) – replaces the embedded lib route.
 */
add_action('rest_api_init', function(){
    $s=oha_bhs_get(); $path=trim($s['stripe']['endpoint_path'],'/'); $p=explode('/',$path);
    if(count($p)>=2){ $ns=$p[0].'/'.$p[1]; $rt='/'.implode('/',array_slice($p,2)); if($rt==='/') $rt='/stripe-webhook'; }
    else { $ns='oha/v1'; $rt='/stripe-webhook'; }
    register_rest_route($ns, $rt, array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>'oha_bhs_handle_webhook'));
});

function oha_bhs_handle_webhook(WP_REST_Request $req){
    if(!function_exists('oha_sm_get')) return new WP_REST_Response(array('error'=>'stripe_lib_missing'),500);
    $s = oha_sm_get();
    $payload = $req->get_body(); $sig = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    $secret = $s['webhook_secret'] ?? ''; $tol = intval($s['timestamp_tolerance'] ?? 300);
    if(!$secret || !$sig || !$payload) return new WP_REST_Response(array('error'=>'missing'), 400);
    if(!function_exists('oha_sm_verify_sig')) return new WP_REST_Response(array('error'=>'verify_missing'),500);
    if(!oha_sm_verify_sig($payload,$sig,$secret,$tol)) return new WP_REST_Response(array('error'=>'sig_failed'), 400);
    $event = json_decode($payload);
    if(!$event || empty($event->type)) return new WP_REST_Response(array('error'=>'bad_json'),400);

    try{
        switch($event->type){
            case 'checkout.session.completed':
                oha_sm_save_from_checkout_session($event->data->object??null); break;
            case 'customer.created':
            case 'customer.updated':
                oha_sm_save_from_customer($event->data->object??null); break;
            case 'customer.subscription.created':
            case 'customer.subscription.updated':
                $sub=$event->data->object??null;
                if($sub){
                    if(!empty($sub->customer)){
                        $customer=oha_sm_stripe_get('/v1/customers/'.urlencode($sub->customer));
                        if(!empty($customer)&&empty($customer->error)) oha_sm_save_from_customer($customer);
                    }
                    $cancel_at_period_end = !empty($sub->cancel_at_period_end);
                    $status = $sub->status ?? '';
                    if($cancel_at_period_end && $status==='active'){
                        $when = intval($sub->current_period_end ?? 0);
                        if($when>0){
                            $sub_id = sanitize_text_field($sub->id ?? '');
                            $cust_id = sanitize_text_field($sub->customer ?? '');
                            $payload = array('sub_id'=>$sub_id, 'customer_id'=>$cust_id);
                            wp_schedule_single_event($when + 60, 'oha_bhs_downgrade_event', array($payload));
                        }
                    }
                }
                break;
            case 'invoice.payment_succeeded':
                break;
            case 'customer.subscription.deleted':
                $sub=$event->data->object??null; if($sub && !empty($sub->id)){
                    oha_bhs_apply_free_level_from_sub_id(sanitize_text_field($sub->id));
                }
                break;
        }
    }catch(Throwable $e){
        if(function_exists('oha_sm_log')) oha_sm_log('Suite Webhook exception: '.$e->getMessage());
        return new WP_REST_Response(array('error'=>'server'),500);
    }
    return new WP_REST_Response(array('ok'=>true),200);
}

// Cron: apply free level when cancel_at_period_end triggers
add_action('oha_bhs_downgrade_event', function($payload){
    $sub_id = $payload['sub_id'] ?? ''; if(!$sub_id) return;
    oha_bhs_apply_free_level_from_sub_id($sub_id);
}, 10, 1);

function oha_bhs_apply_free_level_from_sub_id($sub_id){
    $sub_id = sanitize_text_field($sub_id);
    $users = get_users(array('meta_key'=>'stripe_subscription_id','meta_value'=>$sub_id,'number'=>1,'fields'=>'ID'));
    if(empty($users)) return;
    $uid = (int) $users[0];
    $free_level = intval(oha_bhs_get()['swpm']['free_level_id']);
    oha_bhs_set_swpm_level($uid, $free_level);
}

function oha_bhs_set_swpm_level($wp_user_id, $level_id){
    global $wpdb;
    $table=$wpdb->prefix.'swpm_members_tbl';
    $exists=$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
    if(!$exists) return false;
    $u = get_userdata($wp_user_id); if(!$u) return false;
    $cols=$wpdb->get_results("DESCRIBE {$table}", ARRAY_A); $names=wp_list_pluck($cols,'Field');
    if(in_array('wp_user_id',$names,true)){
        $wpdb->update($table, array('membership_level'=>$level_id, 'account_state'=>'active'), array('wp_user_id'=>$wp_user_id));
    } else {
        $wpdb->update($table, array('membership_level'=>$level_id, 'account_state'=>'active'), array('email'=>$u->user_email));
    }
    return true;
}


function oha_bhs_tab_discounts(){
    if(!current_user_can('manage_options') && !current_user_can('manage_oha_members') && !current_user_can('read_oha_board_hub')){
        echo '<p><em>Access restricted.</em></p>'; return;
    }
    echo '<h2>Haunt Discounts</h2>';
    if (shortcode_exists('oha_haunt_discounts_admin')) {
        echo do_shortcode('[oha_haunt_discounts_admin]');
    } else {
        echo '<p><em>Module not loaded.</em></p>';
    }
}
